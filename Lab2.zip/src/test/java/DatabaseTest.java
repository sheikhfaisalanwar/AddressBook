
import java.util.List;

import static org.junit.Assert.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class DatabaseTest {
    BuddyInfo buddy1;
    BuddyInfo buddy2;
    BuddyInfo buddy3;
    BuddyInfo buddy4;

    AddressBook addressBookDatabase1;
    AddressBook addressBookDatabase2;

    EntityManagerFactory emf;
    EntityManager em;
    EntityTransaction transaction;


    @org.junit.Before
    public void setUp() throws Exception {
        buddy1 = new BuddyInfo();
        buddy1.setName("Pen");
        buddy1.setAddress("123 Apple");
        buddy1.setPhoneNumber("111");

        buddy2 = new BuddyInfo();
        buddy2.setName("PineApple");
        buddy2.setAddress("123 PineApple");
        buddy2.setPhoneNumber("222");

        buddy3 = new BuddyInfo();
        buddy3.setName("Fruit");
        buddy3.setAddress("123 Fruit");
        buddy3.setPhoneNumber("333");

        buddy4 = new BuddyInfo();
        buddy4.setName("GrapeFruit");
        buddy4.setAddress("123 GrapeFruit");
        buddy4.setPhoneNumber("444");

        addressBookDatabase1 = new AddressBook();
        addressBookDatabase2 = new AddressBook();

        // Connecting to the database through EntityManagerFactory
        // connection details loaded from persistence.xml
        emf = Persistence.createEntityManagerFactory("addrUnit");
        em = emf.createEntityManager();

        //Creating Transaction
        transaction = em.getTransaction();
        transaction.begin();
    }

    @org.junit.After
    public void tearDown() throws Exception {

        // Closing connection
        em.close();
        emf.close();

    }


    @org.junit.Test
    public void testDatabaseCreation(){

        /***Persist address book itself***/
        em.persist(addressBookDatabase1);
        em.persist(addressBookDatabase2);



        /***Add Buddies To AddressBook***/
        addressBookDatabase1.addBuddy(buddy1);
        addressBookDatabase1.addBuddy(buddy2);

        addressBookDatabase2.addBuddy(buddy3);
        addressBookDatabase2.addBuddy(buddy4);

        /***PERSIST BUDDY INFO***/
        em.persist(buddy1);
        em.persist(buddy2);



        transaction.commit();

        //Query contents
        Query query = em.createQuery("SELECT a FROM AddressBook a");

        @SuppressWarnings("unchecked")
        List<AddressBook> results = query.getResultList();

        System.out.println("AddressBook Database\n----------------");
        for(AddressBook a: results){

            System.out.println(a.toString());
            if(a.getId() == 1) {
                assertEquals("AddressBook for Database 1", "AddressBook ID: 1\n" +
                        "BuddyID: 3, Name: Pen, Address: 123 Apple, Phone Number: 111\n" +
                        "BuddyID: 4, Name: PineApple, Address: 123 PineApple, Phone Number: 222\n", a.toString());
            }

            if(a.getId() == 2) {
                assertEquals("AddressBook for Database 2", "AddressBook ID: 2\n" +
                        "BuddyID: 5, Name: Fruit, Address: 123 Fruit, Phone Number: 333\n" +
                        "BuddyID: 6, Name: GrapeFruit, Address: 123 GrapeFruit, Phone Number: 444\n", a.toString());
            }


        }

    }

}