import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class JPATest {
    public void performJPA(){
        BuddyInfo buddy1 = new BuddyInfo();
        buddy1.setName("Pen");
        buddy1.setAddress("123 Apple");
        buddy1.setPhoneNumber("111");

        BuddyInfo buddy2 = new BuddyInfo();
        buddy2.setName("PineApple");
        buddy2.setAddress("123 PineApple");
        buddy2.setPhoneNumber("222");

        BuddyInfo buddy3 = new BuddyInfo();
        buddy3.setName("Fruit");
        buddy3.setAddress("123 Fruit");
        buddy3.setPhoneNumber("333");

        BuddyInfo buddy4 = new BuddyInfo();
        buddy4.setName("GrapeFruit");
        buddy4.setAddress("123 GrapeFruit");
        buddy4.setPhoneNumber("444");


        // Connecting to the database through EntityManagerFactory
        // connection details loaded from persistence.xml
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("addrUnit");
        EntityManager em = emf.createEntityManager();

        //Creating Transaction
        EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        AddressBook addressBookDatabase1 = new AddressBook();
        AddressBook addressBookDatabase2 = new AddressBook();






        /***Persist address book itself***/
        em.persist(addressBookDatabase1);
        em.persist(addressBookDatabase2);



        /***Add Buddies To AddressBook***/
        addressBookDatabase1.addBuddy(buddy1);
        addressBookDatabase1.addBuddy(buddy2);

        addressBookDatabase2.addBuddy(buddy3);
        addressBookDatabase2.addBuddy(buddy4);

        /***PERSIST BUDDY INFO***/
        em.persist(buddy1);
        em.persist(buddy2);
        em.persist(buddy3);
        em.persist(buddy4);


        transaction.commit();

        //Query contents
        Query query = em.createQuery("SELECT a FROM AddressBook a");

        @SuppressWarnings("unchecked")
        List<AddressBook> results = query.getResultList();

        System.out.println("AddressBook Database\n----------------");
        for(AddressBook a: results){
            System.out.println(a.toString());
        }

        // Closing connection
        em.close();
        emf.close();


    }

}